import SwiftUI

struct ContentView: View {
    private let siteURL = URL(string: "https://shosetsu-toukou-site.org")!

    var body: some View {
        WebView(url: siteURL)
            .ignoresSafeArea()
    }
}
